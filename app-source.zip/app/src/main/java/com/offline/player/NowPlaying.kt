package com.offline.player

import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlin.math.PI
import kotlin.math.sin

// ───────────────────────── Now Playing ─────────────────────────
// Colours come from LocalUi, which PlayerApp derives from the current track's artwork
// and crossfades whenever the track changes.

/** Estimated height of everything on Now Playing except the artwork, and the smallest content height before scrolling starts. */
private val CHROME = 390.dp
private val MIN_CONTENT = 600.dp

/** Stable per-song bar heights. This is a visual style for the seek bar, not analysed audio. */
fun waveHeights(seed: Long, n: Int): FloatArray {
    var s = seed xor 0x2545F4914F6CDD1DL
    val out = FloatArray(n)
    for (i in 0 until n) {
        s = s * 6364136223846793005L + 1442695040888963407L
        val r = ((s ushr 40) and 0xFFFF).toInt() / 65535f
        val env = 0.35f + 0.65f * sin(PI * (i + .5) / n).toFloat()
        out[i] = ((0.18f + 0.82f * r) * env).coerceIn(.08f, 1f)
    }
    return out
}

/** Bar-style seek control: tap or drag to seek, and exposes slider semantics to TalkBack. */
@Composable
fun WaveSeek(
    seed: Long, frac: Float, enabled: Boolean, played: Color, idle: Color, state: String,
    onSeek: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier
) {
    val bars = remember(seed) { waveHeights(seed, 64) }
    val seek by rememberUpdatedState(onSeek)
    val done by rememberUpdatedState(onDone)
    Canvas(
        modifier.fillMaxWidth().height(56.dp)
            .semantics {
                contentDescription = "Seek"
                stateDescription = state
                progressBarRangeInfo = ProgressBarRangeInfo(frac, 0f..1f)
                if (enabled) setProgress { v -> seek(v.coerceIn(0f, 1f)); done(); true }
            }
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { o -> seek((o.x / size.width).coerceIn(0f, 1f)); done() }
            }
            .pointerInput(enabled) {
                if (enabled) detectHorizontalDragGestures(
                    onDragStart = { o -> seek((o.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { done() }, onDragCancel = { done() }
                ) { change, _ -> change.consume(); seek((change.position.x / size.width).coerceIn(0f, 1f)) }
            }
    ) {
        val n = bars.size
        val bw = this.size.width / n * 0.55f
        for (i in 0 until n) {
            val x = this.size.width * (i + .5f) / n
            val h = this.size.height * bars[i]
            drawRoundRect(
                color = if ((i + .5f) / n <= frac) played else idle,
                topLeft = Offset(x - bw / 2, (this.size.height - h) / 2),
                size = Size(bw, h), cornerRadius = CornerRadius(bw / 2)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun NowPlaying(app: AppState, sleepLabel: String, onSleep: () -> Unit, onQueue: () -> Unit, onClose: () -> Unit) {
    val ps = app.ps
    val u = LocalUi.current
    val m = LocalMotion.current
    val ctx = LocalContext.current
    val item = ps.current ?: return
    val songId = item.mediaId.toLongOrNull()
    val fav = songId != null && songId in app.prefs.favs
    val fadeMs = when (m) { 0 -> 450; 1 -> 150; else -> 0 }

    // safeDrawing = status bar + navigation bar + display cutout (+ IME), so nothing hides behind system UI.
    BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
        // Layout model: the content block is at least MIN_CONTENT tall (so short screens / big fonts scroll instead of
        // crushing the controls) and otherwise exactly as tall as the screen. Leftover height is shared out through weighted
        // spacers, which keeps the controls balanced under the artwork instead of clustering at the top.
        val contentH = maxOf(maxHeight, MIN_CONTENT)
        val artSize = minOf(maxWidth - 64.dp, contentH - CHROME - 44.dp, 380.dp).coerceAtLeast(140.dp)
        val scale by animateFloatAsState(if (ps.playing || m != 0) 1f else .94f, tween(400), label = "artScale")
        var drag by remember { mutableStateOf<Float?>(null) }

        Column(
            Modifier.align(Alignment.TopCenter).widthIn(max = 560.dp).fillMaxWidth()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
        // A fixed height inside the scroll container gives the weighted spacers a bounded size to divide.
        Column(Modifier.fillMaxWidth().height(contentH), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                GlassCircleBtn(P.ChevronLeft, "Close Now Playing", onClose)
                Text("Now Playing", fontSize = 16.sp, color = u.text, fontWeight = FontWeight.Medium)
                GlassCircleBtn(if (fav) P.Heart else P.HeartOutline, if (fav) "Remove from favorites" else "Add to favorites",
                    { songId?.let { app.prefs.toggleFav(it) } }, tint = if (fav) u.accent else u.text)
            }
            Spacer(Modifier.height(12.dp)); Spacer(Modifier.weight(.8f))

            Crossfade(item, animationSpec = tween(fadeMs), label = "npArt") { cur ->
                if (LocalArtShape.current == 2) {
                    RotatingHaloArt(cur.mediaMetadata.artworkUri, cur.mediaMetadata.title?.toString() ?: "", artSize, ps.playing, m, scale)
                } else {
                    val shape = artShape(28.dp)
                    Box(
                        Modifier.graphicsLayer { scaleX = scale; scaleY = scale }
                            .shadow(24.dp, shape, ambientColor = u.accent, spotColor = u.accent)
                    ) { Art(cur.mediaMetadata.artworkUri, cur.mediaMetadata.title?.toString() ?: "", artSize, 28.dp, shape = shape) }
                }
            }
            Spacer(Modifier.height(12.dp)); Spacer(Modifier.weight(.6f))

            Crossfade(item, animationSpec = tween(fadeMs), label = "npText") { cur ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        cur.mediaMetadata.title?.toString() ?: "", fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, textAlign = TextAlign.Center, color = u.text,
                        overflow = if (m == 0) TextOverflow.Clip else TextOverflow.Ellipsis,
                        modifier = if (m == 0) Modifier.basicMarquee(iterations = Int.MAX_VALUE) else Modifier
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        listOfNotNull(cur.mediaMetadata.artist, cur.mediaMetadata.albumTitle?.takeIf { it.isNotBlank() })
                            .joinToString(" · "),
                        fontSize = 13.sp, color = u.dim, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                    )
                }
            }
            Spacer(Modifier.height(14.dp)); Spacer(Modifier.weight(.9f))

            val frac = drag ?: if (ps.dur > 0) (ps.pos.toFloat() / ps.dur).coerceIn(0f, 1f) else 0f
            val shownPos = if (drag != null) (frac * ps.dur).toLong() else ps.pos
            val finish = { drag?.let { ps.controller?.seekTo((it * ps.dur).toLong()) }; drag = null }
            if (app.prefs.seekStyle == 0) {
                WaveSeek(
                    songId ?: 0L, frac, ps.dur > 0, u.text, u.text.copy(.35f), "${fmt(shownPos)} of ${fmt(ps.dur)}",
                    { drag = it }, { finish() }
                )
            } else {
                Slider(
                    value = frac, onValueChange = { drag = it }, onValueChangeFinished = { finish() }, enabled = ps.dur > 0,
                    modifier = Modifier.semantics { contentDescription = "Seek"; stateDescription = "${fmt(shownPos)} of ${fmt(ps.dur)}" },
                    colors = SliderDefaults.colors(
                        thumbColor = u.text, activeTrackColor = u.text, inactiveTrackColor = u.text.copy(.3f),
                        disabledThumbColor = u.dim, disabledActiveTrackColor = u.dim.copy(.5f), disabledInactiveTrackColor = u.text.copy(.12f)
                    )
                )
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(shownPos), fontSize = 12.sp, color = u.dim)
                Text(fmt(ps.dur), fontSize = 12.sp, color = u.dim)
            }
            Spacer(Modifier.height(10.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconBtn(P.Shuffle, if (ps.shuffle) "Shuffle on" else "Shuffle off",
                    { ps.controller?.let { it.shuffleModeEnabled = !ps.shuffle } },
                    tint = if (ps.shuffle) u.accentText else u.dim)
                IconBtn(P.Prev, "Previous track", { ps.controller?.seekToPrevious() }, sz = 32.dp)
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(Color.White.copy(.30f))
                        .semantics { contentDescription = if (ps.playing) "Pause" else "Play" }
                        .clickable(role = Role.Button) { ps.toggle() },
                    contentAlignment = Alignment.Center
                ) { Ico(if (ps.playing) P.Pause else P.Play, Color.White, 36.dp) }
                IconBtn(P.Next, "Next track", { ps.controller?.seekToNext() }, sz = 32.dp)
                IconBtn(P.Queue, "Open queue", onQueue, tint = u.dim)
            }
            Spacer(Modifier.height(10.dp)); Spacer(Modifier.weight(.5f))

            FlowRow(
                Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val repeatDesc = when (ps.repeat) { Player.REPEAT_MODE_ALL -> "Repeat all"; Player.REPEAT_MODE_ONE -> "Repeat one"; else -> "Repeat off" }
                IconBtn(if (ps.repeat == Player.REPEAT_MODE_ONE) P.RepeatOne else P.Repeat, repeatDesc, {
                    ps.controller?.let {
                        it.repeatMode = when (ps.repeat) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    }
                }, tint = if (ps.repeat != Player.REPEAT_MODE_OFF) u.accentText else u.dim)
                IconBtn(P.PlaylistAdd, "Add to playlist", {
                    val s = songId?.let { app.byId[it] }
                    if (s != null) app.pickFor = listOf(s)
                    else Toast.makeText(ctx, "Track not found in library", Toast.LENGTH_SHORT).show()
                }, tint = u.dim)
                Chip(sleepLabel, onClick = onSleep)
                Chip("Speed ${speeds[app.prefs.speed]}x") { app.prefs.setSpeed((app.prefs.speed + 1) % speeds.size) }
            }
            Spacer(Modifier.height(16.dp)); Spacer(Modifier.weight(.4f))
        }
        }
    }
}

// ───────────────────────── Mini-player ─────────────────────────

@Composable
fun MiniPlayer(app: AppState, onOpen: () -> Unit) {
    val ps = app.ps
    val u = LocalUi.current
    val item = ps.current ?: return
    val title = item.mediaMetadata.title?.toString() ?: ""
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).glass(20.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable(onClickLabel = "Open Now Playing", onClick = onOpen).padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Art(item.mediaMetadata.artworkUri, title, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = u.text)
                Text(item.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = u.dim)
            }
            IconBtn(if (ps.playing) P.Pause else P.Play, if (ps.playing) "Pause" else "Play", { ps.toggle() }, tint = u.accentText, sz = 28.dp)
            IconBtn(P.Next, "Next track", { ps.controller?.seekToNext() }, tint = u.text)
        }
        LinearProgressIndicator(
            progress = { if (ps.dur > 0) (ps.pos.toFloat() / ps.dur).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = u.accent, trackColor = Color.Transparent
        )
    }
}

// ───────────────────────── Queue ─────────────────────────

@Composable
fun QueueScreen(app: AppState, onBack: () -> Unit) {
    val ps = app.ps
    val u = LocalUi.current
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(P.Back, "Back", onBack)
            Column(Modifier.weight(1f)) {
                Text("Queue", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = u.text)
                Text("${ps.queue.size} tracks", fontSize = 12.sp, color = u.dim)
            }
            if (ps.queue.size > 1) Chip("Clear") { confirmClear = true }
            Spacer(Modifier.width(8.dp))
        }
        if (ps.shuffle) Text(
            "Shuffle is on: tracks play in a random order, and Play Next inserts into that order.",
            fontSize = 12.sp, color = u.dim, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
        if (ps.queue.isEmpty()) Text("The queue is empty. Play a song or use “Add to queue”.", color = u.dim, modifier = Modifier.padding(24.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(ps.queue) { i, mi ->
                val isCur = i == ps.index
                val title = mi.mediaMetadata.title?.toString() ?: ""
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .then(if (isCur) Modifier.background(u.accent.copy(.14f)) else Modifier)
                        .clickable(onClickLabel = "Play $title") { ps.jumpTo(i) }
                        .padding(start = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Art(mi.mediaMetadata.artworkUri, title, 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = if (isCur) u.accentText else u.text)
                        Text(mi.mediaMetadata.artist?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = u.dim)
                    }
                    var open by remember { mutableStateOf(false) }
                    Box {
                        IconBtn(P.More, "Options for $title", { open = true })
                        DropdownMenu(open, { open = false }) {
                            if (i > 0) DropdownMenuItem(text = { Text("Move up") }, onClick = { open = false; ps.move(i, i - 1) })
                            if (i < ps.queue.lastIndex) DropdownMenuItem(text = { Text("Move down") }, onClick = { open = false; ps.move(i, i + 1) })
                            DropdownMenuItem(text = { Text("Remove from queue") }, onClick = { open = false; ps.removeAt(i) })
                        }
                    }
                }
            }
        }
    }
    if (confirmClear) ConfirmDialog(
        "Clear queue?", "All upcoming and previous tracks will be removed. The current track keeps playing.", "Clear",
        { confirmClear = false; ps.clearUpcoming() }, { confirmClear = false }
    )
}
