package com.offline.player

import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

const val GLOBE = "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM4,12c0,-0.61 0.08,-1.21 0.21,-1.78L8.99,15v1c0,1.1 0.9,2 2,2v1.93C7.06,19.43 4,16.07 4,12zM18.89,17.4C18.63,16.58 17.88,16 17,16h-1v-3c0,-0.55 -0.45,-1 -1,-1H9v-2h2c0.55,0 1,-0.45 1,-1V7h2c1.1,0 2,-0.9 2,-2v-0.41C17.92,5.77 20,8.65 20,12c0,2.08 -0.81,3.98 -2.11,5.4z"

/** Circular artwork that rotates only while playing (and only with full motion), inside an artwork-coloured halo. */
@Composable
fun RotatingHaloArt(model: Any?, seed: String, artSize: Dp, playing: Boolean, motion: Int, scale: Float) {
    val u = LocalUi.current
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing, motion) {
        if (playing && motion == 0) {
            var last = withFrameNanos { it }
            while (true) {
                val t = withFrameNanos { it }
                angle = (angle + (t - last) / 1_000_000_000f * 14f) % 360f
                last = t
            }
        }
    }
    val ring = u.accent
    Box(Modifier.size(artSize + 44.dp).graphicsLayer { scaleX = scale; scaleY = scale }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = artSize.toPx() / 2f + 9.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(ring.copy(alpha = .38f), Color.Transparent), center = center, radius = r * 1.32f),
                radius = r * 1.32f, center = center
            )
            drawCircle(ring.copy(alpha = .30f), radius = r, center = center, style = Stroke(width = 6.dp.toPx()))
            drawCircle(ring.copy(alpha = .95f), radius = r, center = center, style = Stroke(width = 1.6.dp.toPx()))
        }
        Box(Modifier.graphicsLayer { rotationZ = angle }) { Art(model, seed, artSize, 28.dp, shape = CircleShape) }
    }
}

@Composable
fun AboutCard() {
    val u = LocalUi.current
    val ctx = LocalContext.current
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" } }
    Column(Modifier.fillMaxWidth().glass(24.dp).padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("About FR SHAH", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = u.text)
        Text("FR SHAH Music Player", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = u.text)
        Text("Developer and creator: FR SHAH", fontSize = 13.sp, color = u.dim)
        if (ver.isNotBlank()) Text("Version $ver", fontSize = 13.sp, color = u.dim)
        Text(
            "FR SHAH Music Player is a modern music-listening experience designed to combine simple music management, personalized playback, and immersive visual effects in one application.",
            fontSize = 13.sp, color = u.dim
        )
    }
}

// ───────────────────────── Online Music (YouTube / Spotify embeds) ─────────────────────────

private class Link(val platform: String, val embed: String, val external: String)
private class Meta(val title: String, val author: String?, val thumb: String?)

private val ytHosts = setOf("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be")

private fun parseLink(raw: String): Link? {
    val s = raw.trim()
    if (s.isEmpty()) return null
    val uri = try { Uri.parse(if (s.startsWith("http")) s else "https://$s") } catch (e: Exception) { return null }
    val host = uri.host?.lowercase() ?: return null
    val segs = uri.pathSegments
    if (host in ytHosts) {
        val id = when {
            host == "youtu.be" -> segs.firstOrNull()
            segs.firstOrNull() in setOf("shorts", "embed", "live") -> segs.getOrNull(1)
            else -> uri.getQueryParameter("v")
        }
        val pl = uri.getQueryParameter("list")
        return when {
            id != null && Regex("[A-Za-z0-9_-]{11}").matches(id) ->
                Link("YouTube", "https://www.youtube.com/embed/$id?playsinline=1&rel=0" + (pl?.let { "&list=$it" } ?: ""), "https://www.youtube.com/watch?v=$id")
            pl != null && segs.firstOrNull() == "playlist" ->
                Link("YouTube", "https://www.youtube.com/embed/videoseries?list=$pl&playsinline=1", "https://www.youtube.com/playlist?list=$pl")
            else -> null
        }
    }
    if (host == "open.spotify.com") {
        val p = segs.filter { !it.startsWith("intl-") }
        val type = p.getOrNull(0)
        val id = p.getOrNull(1)
        if (type in setOf("track", "album", "playlist", "episode", "show", "artist") && id != null && Regex("[A-Za-z0-9]{22}").matches(id))
            return Link("Spotify", "https://open.spotify.com/embed/$type/$id", "https://open.spotify.com/$type/$id")
    }
    return null
}

private suspend fun fetchMeta(l: Link): Meta? = withContext(Dispatchers.IO) {
    try {
        val api = if (l.platform == "YouTube") "https://www.youtube.com/oembed?format=json&url=" else "https://open.spotify.com/oembed?url="
        val c = URL(api + URLEncoder.encode(l.external, "UTF-8")).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        if (c.responseCode != 200) return@withContext null
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        Meta(j.optString("title"), j.optString("author_name").takeIf { it.isNotBlank() }, j.optString("thumbnail_url").takeIf { it.isNotBlank() })
    } catch (e: Exception) { null }
}

@Composable
private fun EmbedView(l: Link) {
    val allowed = listOf("youtube.com", "spotify.com", "google.com")
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val h = request.url.host ?: return true
                        return allowed.none { h.endsWith(it) }
                    }
                }
            }
        },
        update = {
            if (it.tag != l.embed) {
                it.tag = l.embed
                if (l.platform == "YouTube") it.loadUrl(l.embed, mapOf("Referer" to "https://com.offline.player")) else it.loadUrl(l.embed)
            }
        },
        onRelease = { it.destroy() },
        modifier = Modifier.fillMaxWidth().height(if (l.platform == "Spotify") 232.dp else 210.dp).clip(RoundedCornerShape(16.dp))
    )
}

@Composable
fun OnlineScreen(app: AppState) {
    val u = LocalUi.current
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var text by rememberSaveable { mutableStateOf("") }
    var opened by rememberSaveable { mutableStateOf("") }          // survives tab switches and rotation
    val link = remember(opened) { parseLink(opened) }
    var recent by remember { mutableStateOf((app.prefs.raw.getString("recent_links", "") ?: "").split('\n').filter { it.isNotBlank() }) }
    var error by remember { mutableStateOf<String?>(null) }
    var meta by remember { mutableStateOf<Meta?>(null) }
    var metaState by remember { mutableIntStateOf(0) } // 0 idle, 1 loading, 2 loaded, 3 unavailable
    LaunchedEffect(link) {
        val l = link ?: return@LaunchedEffect
        metaState = 1
        meta = fetchMeta(l)
        metaState = if (meta != null) 2 else 3
    }
    fun load(raw: String = text) {
        val l = parseLink(raw)
        if (l == null) {
            opened = ""
            error = if (text.isBlank()) "Paste a YouTube or Spotify link first." else "That isn’t a supported YouTube or Spotify link."
            return
        }
        error = null
        meta = null
        text = raw
        opened = raw
        recent = (listOf(l.external) + recent.filter { it != l.external }).take(5)
        app.prefs.raw.edit().putString("recent_links", recent.joinToString("\n")).apply()
        app.ps.controller?.pause()
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("Online Music", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = u.text)
        OutlinedTextField(
            text, { text = it; error = null }, singleLine = true, isError = error != null,
            placeholder = { Text("Paste a YouTube or Spotify link") },
            supportingText = { error?.let { Text(it) } },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = u.text, unfocusedTextColor = u.text, focusedBorderColor = u.accent,
                unfocusedBorderColor = u.border, cursorColor = u.accent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Paste") { clip.getText()?.text?.let { text = it; error = null } }
            Chip("Open", true) { load() }
        }
        if (link == null && recent.isNotEmpty()) {
            Text("Recent links", fontSize = 13.sp, color = u.dim)
            recent.forEach { r ->
                Text(r.removePrefix("https://"), color = u.accentText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().clickable(onClickLabel = "Open this link") { load(r) }.padding(vertical = 8.dp))
            }
            Chip("Clear recent") { recent = emptyList(); app.prefs.raw.edit().remove("recent_links").apply() }
        }
        link?.let { l ->
            Column(Modifier.fillMaxWidth().glass(24.dp).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Detected: ${l.platform}", color = u.accentText, fontWeight = FontWeight.SemiBold)
                when (metaState) {
                    1 -> Text("Loading details…", color = u.dim, fontSize = 13.sp)
                    2 -> meta?.let { m ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (m.thumb != null) {
                                AsyncImage(m.thumb, null, Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(12.dp))
                            }
                            Column {
                                Text(m.title, color = u.text, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                m.author?.let { Text(it, color = u.dim, fontSize = 12.sp) }
                            }
                        }
                    }
                    3 -> Text("Details aren’t available. The link may be private or removed, or you may be offline.", color = u.dim, fontSize = 13.sp)
                }
                EmbedView(l)
                Chip("Open in ${l.platform}") {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(l.external)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (e: Exception) { android.widget.Toast.makeText(ctx, "No app or browser can open this link", android.widget.Toast.LENGTH_SHORT).show() }
                }
                Text(
                    if (l.platform == "Spotify") "Spotify plays a preview here unless you sign in to Spotify in this player. Full songs may need the Spotify app."
                    else "If a video won’t play here, its owner may have blocked embedding. Use Open in YouTube.",
                    fontSize = 12.sp, color = u.dim
                )
            }
        }
        Text(
            "Downloading from YouTube or Spotify isn’t supported. Their terms don’t allow it. Your own music files still play offline in My Music. This tab needs internet.",
            fontSize = 12.sp, color = u.dim
        )
        Spacer(Modifier.height(16.dp))
    }
}
